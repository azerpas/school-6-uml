package TP1;

public enum LockingType {
    HL, SL_AdminMode, SL_UserMode, 
}
