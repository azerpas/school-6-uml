package TP1;

public enum CustomerType {
    Individual, Company
}
