package TP1;

public enum EntitlementType {
    Contract
}
